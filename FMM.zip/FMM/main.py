from particle import Particle
from index import Index
from fmm import FMM
import numpy as np
np.random.seed(0)


def main():
    N = 100
    epsilon = 1e-10

    precision = int(-np.log2(epsilon))
    max_level = int(np.log(N) / np.log(4))

    particles = [Particle() for _ in range(N)]

    fmm = FMM(precision, max_level)
    fmm.fmm_algorithm(particles)
    return


if __name__ == "__main__":
    main()
